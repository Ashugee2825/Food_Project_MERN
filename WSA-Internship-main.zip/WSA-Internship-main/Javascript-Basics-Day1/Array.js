//camelCase
let myArray = [1, "two", { name: "John", age: 20 }, [4, 5, 6]];
document.write(myArray);
