//Case Sensitive

let sum = 23;
let Sum = 32;
let SUM = 10;
document.write("sum: " + sum + "<br/>");
document.write("Sum: " + Sum + "<br/>");
document.write("SUM: " + SUM + "<br/>");
