let a = 23;
let b = 32;
let add = a + b;
window.alert("Welcome to this website!");
document.write(" browser: " + add); //55
console.log(" console: " + add); //55; will come in console
