let person = {
  name: "John",
  age: 21,
  occupation: "Softeware Engineer",
};
//dot notation we can access these properties

document.write(person.name + ",\n" + person.occupation);

//update the properties
person.name = "SRK";

document.write("<br/>" + person.name + ",\n" + person.occupation);
